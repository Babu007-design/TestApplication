import { Nuts } from './nuts';

describe('Nuts', () => {
  it('should create an instance', () => {
    expect(new Nuts()).toBeTruthy();
  });
});
