export class Nuts {
    imagedata: any;
}
